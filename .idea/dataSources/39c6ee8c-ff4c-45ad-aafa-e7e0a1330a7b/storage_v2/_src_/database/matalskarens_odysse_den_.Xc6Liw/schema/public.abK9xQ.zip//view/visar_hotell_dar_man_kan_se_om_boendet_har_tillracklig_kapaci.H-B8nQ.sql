create view visar_hotell_där_man_kan_se_om_boendet_har_tillräcklig_kapaci(hotel_name, room_type, total_beds, adults, kids) as
SELECT h.hotel_name,
       r.room_type,
       r.total_beds,
       booking.adults,
       booking.kids
FROM booking
         JOIN hotel h ON h.id = booking.hotel_id
         JOIN booking_x_room bxr ON booking.id = bxr.booking_id
         JOIN room r ON r.id = bxr.room_id;

alter table visar_hotell_där_man_kan_se_om_boendet_har_tillräcklig_kapaci
    owner to postgres;

